<div class="edit-firmware">
    <a href="/firmware/table" class="btn btn-primary"><i class="fas fa-table"></i>
        Edit
    </a>

    <a href="#" class="btn btn-success" data-toggle="modal" data-target="#importModal"><i
            class="fas fa-file-import"></i> Import</a>
    <a href="{{ route('export.firmwares') }}" class="btn btn text-white" style="background-color: #F05025"><i
            class="fa-solid fa-download" style="color: #ffffff;"></i>
        Export</a>
</div>
