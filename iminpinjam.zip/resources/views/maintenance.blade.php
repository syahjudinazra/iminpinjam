@extends('layouts.app')
<div class="maintenance">
    <div class="maintenance_contain">
        <img src="https://demo.wpbeaveraddons.com/wp-content/uploads/2018/02/main-vector.png" alt="maintenance">
        <span class="pp-infobox-title-prefix">WE ARE COMING SOON</span>
        <div class="pp-infobox-title-wrapper">
            <h3 class="pp-infobox-title">The website under maintenance!</h3>
        </div>
        <div class="pp-infobox-description">
            <p>The website is under construction to update the data. please wait patiently<br>will resolve this issue in
                24/7 hours
            </p>
        </div>
        <span class="title-text pp-primary-title">Thanks for visiting</span>
    </div>
</div>
