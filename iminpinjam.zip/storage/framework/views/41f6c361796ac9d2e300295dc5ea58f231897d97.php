<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <?php if(request()->is('pinjam')): ?>
                <h1 class="h3 mb-0 text-gray-800">Peminjaman Barang</h1>
            <?php endif; ?>
            <?php if(request()->is('kembali')): ?>
                <h1 class="h3 mb-0 text-gray-800">Pengembalian Barang</h1>
            <?php endif; ?>

            <a href="<?php echo e(route('export-pinjam')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">
                <i class="fas fa-download fa-sm text-white-50"></i> Generate Excel</a>
        </div>

        <?php if(request()->is('pinjam')): ?>
            <button type="button" class="btn btn-danger mb-2" data-toggle="modal" data-target="#exampleModal">
                <i class="fa-solid fa-plus"></i> Tambah Produk
            </button>
        <?php endif; ?>

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form method="GET" action="<?php echo e(route('search.index')); ?>"
            class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search"
            style="float: right">
            <div class="input-group" style="flex-wrap: nowrap;">
                <div class="form-outline ">
                    <input type="search" id="form1" name="search" class="form-control"
                        value="<?php echo e(request()->input('search')); ?>" />
                    <label class="form-label" for="form1">Search</label>
                </div>
                <button type="submit" class="btn btn-danger d-inline">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>

        <!-- Tambah Data -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Pinjam Barang</h5>


                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post" action="/pinjam" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="tanggal" class="form-label"><b>Tanggal</b></label>
                                <input type="date" class="form-control" id="tanggal" name="tanggal">
                            </div>
                            <div class="mb-3">
                                <label for="serialnumber" class="form-label"><b>Serial Number</b></label>
                                <input type="text" class="form-control" id="serialnumber" name="serialnumber"
                                    placeholder="Masukan Serial Number">
                            </div>
                            <div class="form-group mb-3">
                                <label for="device"><b>Tipe Device</b></label>
                                <select class="form-control selectpicker" name="device" id="device"
                                    data-live-search="true" required>
                                    <option value="Pilih Device">Pilih Device</option>
                                    <option value="D1" data-tokens="D1">D1</option>
                                    <option value="D1 Moka" data-tokens="D1 Moka">D1 Moka</option>
                                    <option value="D1-Pro" data-tokens="D1-Pro">D1-Pro</option>
                                    <option value="D1w" data-tokens="D1w">D1w</option>
                                    <option value="D2-401" data-tokens="D2-401">D2-401</option>
                                    <option value="D2-402" data-tokens="D2-402">D2-402</option>
                                    <option value="D2-Pro" data-tokens="D2-Pro">D2-Pro</option>
                                    <option value="D3-504 lama" data-tokens="">D3-504 lama</option>
                                    <option value="D3-505 lama" data-tokens="D3-505 lama">D3-505 lama</option>
                                    <option value="D3-506 lama" data-tokens="D3-506 lama">D3-506 lama</option>
                                    <option value="D3-504" data-tokens="D3-504">D3-504</option>
                                    <option value="D3-505" data-tokens="D3-505">D3-505</option>
                                    <option value="D3-506" data-tokens="D3-506">D3-506</option>
                                    <option value="D3-501 Moka" data-tokens="D3-501 Moka">D3-501 Moka</option>
                                    <option value="D3-503 Moka" data-tokens="D3-503 Moka">D3-503 Moka</option>
                                    <option value="D3 DS1" data-tokens="D3 DS1">D3 DS1</option>
                                    <option value="D3 DS1 Extention Display" data-tokens="D3 DS1 Extention Display">D3 DS1
                                        Extention Display</option>
                                    <option value="D3 DS1 Extention Display TS" data-tokens="D3 DS1 Extention Display TS">
                                        D3
                                        DS1 Extention Display TS</option>
                                    <option value="D4-502" data-tokens="D4-502">D4-502</option>
                                    <option value="D4-503" data-tokens="D4-503">D4-503</option>
                                    <option value="D4-503 White" data-tokens="D4-503 White">D4-503 White</option>
                                    <option value="D4-504" data-tokens="D4-504">D4-504</option>
                                    <option value="D4-504 White" data-tokens="D4-504 White">D4-504 White</option>
                                    <option value="D4-505" data-tokens="D4-505">D4-505</option>
                                    <option value="D4-505 DT" data-tokens="D4-505 DT">D4-505 DT</option>
                                    <option value="D4 Falcon 1" data-tokens="D4 Falcon 1">D4 Falcon 1</option>
                                    <option value="M2-202" data-tokens="M2-202">M2-202</option>
                                    <option value="M2-202 iSeller" data-tokens="M2-202 iSeller">M2-202 iSeller</option>
                                    <option value="M2-203" data-tokens="M2-203">M2-203</option>
                                    <option value="M2-203 iSeller" data-tokens="M2-203 iSeller">M2-203 iSeller</option>
                                    <option value="M2-203 White" data-tokens="M2-203 White">M2-203 White</option>
                                    <option value="M2 Pro" data-tokens="M2 Pro">M2 Pro</option>
                                    <option value="M2 Max" data-tokens="M2 Max">M2 Max</option>
                                    <option value="M2 Swift 1S" data-tokens="M2 Swift 1S">M2 Swift 1S</option>
                                    <option value="M2 Swift 1P" data-tokens="M2 Swift 1P">M2 Swift 1P</option>
                                    <option value="M2 Swift PDA" data-tokens="M2 Swift PDA">M2 Swift PDA</option>
                                    <option value="M2 Swift 1 Scanner" data-tokens="M2 Swift 1 Scanner">M2 Swift 1 Scanner
                                    </option>
                                    <option value="M2 Swift 1 Printer" data-tokens="M2 Swift 1 Printer">M2 Swift 1 Printer
                                    </option>
                                    <option value="R1-201" data-tokens="R1-201">R1-201</option>
                                    <option value="R1-202" data-tokens="R1-202">R1-202</option>
                                    <option value="S1-701" data-tokens="S1-701">S1-701</option>
                                    <option value="K1-101" data-tokens="K1-101">K1-101</option>
                                    <option value="K2-201" data-tokens="K2-201">K2-201</option>
                                    <option value="X1 Scanner" data-tokens="X1 Scanner">X1 Scanner</option>
                                    <option value="Stand S1" data-tokens="Stand S1">Stand S1</option>
                                    <option value="Stand Swan" data-tokens="Stand Swan">Stand Swan</option>
                                    <option value="Charger Docking" data-tokens="Charger Docking">Charger Docking</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="customer" class="form-label"><b>Customer</b></label>
                                <input type="text" class="form-control" id="customer" name="customer"
                                    placeholder="Masukan Nama Customer">
                            </div>
                            <div class="mb-3">
                                <label for="alamat" class="form-label"><b>Alamat</b></label>
                                <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Jl. Pergudangan Ecopark"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="sales" class="form-label"><b>Sales</b></label>
                                <input type="text" class="form-control" id="sales" name="sales"
                                    placeholder="Masukan Nama Sales">
                            </div>
                            <div class="mb-3">
                                <label for="telp" class="form-label"><b>No Telp</b></label>
                                <input type="number" class="form-control" id="telp" name="telp"
                                    placeholder="Masukan No Telp">
                            </div>
                            <div class="mb-3">
                                <label for="pengirim" class="form-label"><b>Pengirim</b></label>
                                <input type="text" class="form-control" id="pengirim" name="pengirim"
                                    placeholder="Masukan Nama Pengirim">
                            </div>
                            <div class="mb-3">
                                <label for="kelengkapankirim" class="form-label"><b>Kelengkapan Kirim</b></label>
                                <textarea class="form-control" id="kelengkapankirim" name="kelengkapankirim" rows="3"
                                    placeholder="Contoh:Adaptor,Dus,Docking"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="gambar" class="form-label"><b>Gambar</b></label>
                                <input class="form-control" type="file" id="gambar" name="gambar">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Tambah</button>
                        </div>
                    </form>
                </div>
                <!-- End Tambah Data -->
            </div>
        </div>
    </div>

    <!-- add edit Data -->
    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="editModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="<?php echo e(route('users.update', $item->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel<?php echo e($item->id); ?>">Edit Data Pinjam</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="tanggal" class="form-label"><b>Tanggal</b></label>
                                <input type="date" class="form-control" id="tanggal" name="tanggal"
                                    value="<?php echo e($item->tanggal); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="serialnumber" class="form-label"><b>Serial Number</b></label>
                                <input type="text" class="form-control" id="serialnumber" name="serialnumber"
                                    value="<?php echo e($item->serialnumber); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="device"><b>Tipe Device</b></label>
                                <select class="form-control selectpicker" name="device" id="device"
                                    data-live-search="true" required>
                                    <option value="Pilih Model">Pilih Model</option>
                                    <option value="D1" data-tokens="D1"
                                        <?php echo e($item->device == 'D1' ? 'selected' : ''); ?>>
                                        D1</option>
                                    <option value="D1 Moka" data-tokens="D1 Moka"
                                        <?php echo e($item->device == 'D1 Moka' ? 'selected' : ''); ?>>D1 Moka</option>
                                    <option value="D1-Pro" data-tokens="D1-Pro"
                                        <?php echo e($item->device == 'D1-Pro' ? 'selected' : ''); ?>>D1-Pro</option>
                                    <option value="D1w" data-tokens="D1w"
                                        <?php echo e($item->device == 'D1w' ? 'selected' : ''); ?>>D1w</option>
                                    <option value="D2-401" data-tokens="D2-401"
                                        <?php echo e($item->device == 'D2-401' ? 'selected' : ''); ?>>D2-401</option>
                                    <option value="D2-402" data-tokens="D2-402"
                                        <?php echo e($item->device == 'D2-402' ? 'selected' : ''); ?>>D2-402</option>
                                    <option value="D2-Pro" data-tokens="D2-Pro"
                                        <?php echo e($item->device == 'D2-Pro' ? 'selected' : ''); ?>>D2-Pro</option>
                                    <option value="D3 504 lama" data-tokens="D3 504 lama"
                                        <?php echo e($item->device == 'D3 504 lama' ? 'selected' : ''); ?>>D3 504 lama</option>
                                    <option value="D3 505 lama" data-tokens="D3 505 lama"
                                        <?php echo e($item->device == 'D3 505 lama' ? 'selected' : ''); ?>>D3 505 lama</option>
                                    <option value="D3 506 lama" data-tokens="D3 506 lama"
                                        <?php echo e($item->device == 'D3 506 lama' ? 'selected' : ''); ?>>D3 506 lama</option>
                                    <option value="D3-504" data-tokens="D3-504"
                                        <?php echo e($item->device == 'D3-504' ? 'selected' : ''); ?>>D3-504</option>
                                    <option value="D3-505" data-tokens="D3-505"
                                        <?php echo e($item->device == 'D3-505' ? 'selected' : ''); ?>>D3-505</option>
                                    <option value="D3-506" data-tokens="D3-506"
                                        <?php echo e($item->device == 'D3-506' ? 'selected' : ''); ?>>D3-506</option>
                                    <option value="D3-501 Moka" data-tokens="D3-501 Moka"
                                        <?php echo e($item->device == 'D3-501 Moka' ? 'selected' : ''); ?>>D3-501 Moka</option>
                                    <option value="D3-503 Moka" data-tokens="D3-503 Moka"
                                        <?php echo e($item->device == 'D3-503 Moka' ? 'selected' : ''); ?>>D3-503 Moka</option>
                                    <option value="D3 DS1" data-tokens="D3 DS1"
                                        <?php echo e($item->device == 'D3 DS1' ? 'selected' : ''); ?>>D3 DS1</option>
                                    <option value="D3 DS1 Extention Display" data-tokens="D3 DS1 Extention Display"
                                        <?php echo e($item->device == 'D3 DS1 Extention Display' ? 'selected' : ''); ?>>D3 DS1
                                        Extention Display</option>
                                    <option value="D3 DS1 Extention Display TS" data-tokens="D3 DS1 Extention Display TS"
                                        <?php echo e($item->device == 'D3 DS1 Extention Display TS' ? 'selected' : ''); ?>>D3 DS1
                                        Extention Display TS</option>
                                    <option value="D4-502" data-tokens="D4-502"
                                        <?php echo e($item->device == 'D4-502' ? 'selected' : ''); ?>>D4-502</option>
                                    <option value="D4-503" data-tokens="D4-503"
                                        <?php echo e($item->device == 'D4-503' ? 'selected' : ''); ?>>D4-503</option>
                                    <option value="D4-503 White" data-tokens="D4-503 White"
                                        <?php echo e($item->device == 'D4-503 White' ? 'selected' : ''); ?>>D4-503 White</option>
                                    <option value="D4-504" data-tokens="D4-504"
                                        <?php echo e($item->device == 'D4-504' ? 'selected' : ''); ?>>D4-504</option>
                                    <option value="D4-504 White" data-tokens="D4-504 White"
                                        <?php echo e($item->device == 'D4-504 White' ? 'selected' : ''); ?>>D4-504 White</option>
                                    <option value="D4-505" data-tokens="D4-505"
                                        <?php echo e($item->device == 'D4-505' ? 'selected' : ''); ?>>D4-505</option>
                                    <option value="D4-505 DT" data-tokens="D4-505 DT"
                                        <?php echo e($item->device == 'D4-505 DT' ? 'selected' : ''); ?>>D4-505 DT</option>
                                    <option value="D4 Falcon 1" data-tokens="D4 Falcon 1"
                                        <?php echo e($item->device == 'D4 Falcon 1' ? 'selected' : ''); ?>>D4 Falcon 1</option>
                                    <option value="M2-202" data-tokens="M2-202"
                                        <?php echo e($item->device == 'M2-202' ? 'selected' : ''); ?>>M2-202</option>
                                    <option value="M2-202 iSeller" data-tokens="M2-202 iSeller"
                                        <?php echo e($item->device == 'M2-202 iSeller' ? 'selected' : ''); ?>>M2-202 iSeller</option>
                                    <option value="M2-203" data-tokens="M2-203"
                                        <?php echo e($item->device == 'M2-203' ? 'selected' : ''); ?>>M2-203</option>
                                    <option value="M2-203 iSeller" data-tokens="M2-203 iSeller"
                                        <?php echo e($item->device == 'M2-203 iSeller' ? 'selected' : ''); ?>>M2-203 iSeller</option>
                                    <option value="M2-203 White" data-tokens="M2-203 White"
                                        <?php echo e($item->device == 'M2-203 White' ? 'selected' : ''); ?>>M2-203 White</option>
                                    <option value="M2 Pro" data-tokens="M2 Pro"
                                        <?php echo e($item->device == 'M2 Pro' ? 'selected' : ''); ?>>M2 Pro</option>
                                    <option value="M2 Max" data-tokens="M2 Max"
                                        <?php echo e($item->device == 'M2 Max' ? 'selected' : ''); ?>>M2 Max</option>
                                    <option value="M2 Swift 1S" data-tokens="M2 Swift 1S"
                                        <?php echo e($item->device == 'M2 Swift 1S' ? 'selected' : ''); ?>>M2 Swift 1S</option>
                                    <option value="M2 Swift 1P" data-tokens="M2 Swift 1P"
                                        <?php echo e($item->device == 'M2 Swift 1P' ? 'selected' : ''); ?>>M2 Swift 1P</option>
                                    <option value="M2 Swift PDA" data-tokens="M2 Swift PDA"
                                        <?php echo e($item->device == 'M2 Swift PDA' ? 'selected' : ''); ?>>M2 Swift PDA</option>
                                    <option value="M2 Swift 1 Scanner" data-tokens="M2 Swift 1 Scanner"
                                        <?php echo e($item->device == 'M2 Swift 1 Scanner' ? 'selected' : ''); ?>>M2 Swift 1 Scanner
                                    </option>
                                    <option value="M2 Swift 1 Printer" data-tokens="M2 Swift 1 Printer"
                                        <?php echo e($item->device == 'M2 Swift 1 Printer' ? 'selected' : ''); ?>>M2 Swift 1 Printer
                                    </option>
                                    <option value="R1 201" data-tokens="R1 201"
                                        <?php echo e($item->device == 'R1 201' ? 'selected' : ''); ?>>R1 201</option>
                                    <option value="R1 202" data-tokens="R1 202"
                                        <?php echo e($item->device == 'R1 202' ? 'selected' : ''); ?>>R1 202</option>
                                    <option value="S1 701" data-tokens="S1 701"
                                        <?php echo e($item->device == 'S1 701' ? 'selected' : ''); ?>>S1 701</option>
                                    <option value="K1 101" data-tokens="K1 101"
                                        <?php echo e($item->device == 'K1 101' ? 'selected' : ''); ?>>K1 101</option>
                                    <option value="K2 201" data-tokens="K1 201"
                                        <?php echo e($item->device == 'K2 201' ? 'selected' : ''); ?>>K2 201</option>
                                    <option value="X1 Scanner" data-tokens="X1 Scanner"
                                        <?php echo e($item->device == 'X1 Scanner' ? 'selected' : ''); ?>>X1 Scanner</option>
                                    <option value="Stand S1" data-tokens="Stand S1"
                                        <?php echo e($item->device == 'Stand S1' ? 'selected' : ''); ?>>Stand S1</option>
                                    <option value="Stand Swan" data-tokens="Stand Swan"
                                        <?php echo e($item->device == 'Stand Swan' ? 'selected' : ''); ?>>Stand Swan</option>
                                    <option value="Charger Docking" data-tokens="Charger Docking"
                                        <?php echo e($item->device == 'Charger Docking' ? 'selected' : ''); ?>>Charger Docking</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="customer" class="form-label"><b>Customer</b></label>
                                <input type="text" class="form-control" id="customer" name="customer"
                                    value="<?php echo e($item->customer); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="alamat" class="form-label"><b>Alamat</b></label>
                                <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo e($item->alamat); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="sales" class="form-label"><b>Sales</b></label>
                                <input type="text" class="form-control" id="sales" name="sales"
                                    value="<?php echo e($item->sales); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="telp" class="form-label"><b>No Telp</b></label>
                                <input type="number" class="form-control" id="telp" name="telp"
                                    value="<?php echo e($item->telp); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="pengirim" class="form-label"><b>Pengirim</b></label>
                                <input type="text" class="form-control" id="pengirim" name="pengirim"
                                    value="<?php echo e($item->pengirim); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="kelengkapankirim" class="form-label"><b>Kelengkapan Kirim</b></label>
                                <textarea class="form-control" id="kelengkapankirim" name="kelengkapankirim" rows="3"><?php echo e($item->kelengkapankirim); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label"><b>Status</b></label>
                                <input type="text" class="form-control" id="status" name="status"
                                    value="<?php echo e($item->status); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="gambar" class="form-label"><b>Gambar</b></label><br>
                                <input class="form-control" type="file" id="gambar" name="gambar">
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-warning">Edit Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end edit data -->

    <!-- view data -->
    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="viewModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="viewModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewModalLabel<?php echo e($item->id); ?>">View Data Pinjam</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="tanggal" class="form-label"><b>Tanggal</b></label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal"
                                value="<?php echo e($item->tanggal); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="serialnumber" class="form-label"><b>Serial Number</b></label>
                            <input type="text" class="form-control" id="serialnumber" name="serialnumber"
                                value="<?php echo e($item->serialnumber); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="device" class="form-label"><b>Device</b></label>
                            <input type="text" class="form-control" id="device" name="device"
                                value="<?php echo e($item->device); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="customer" class="form-label"><b>Customer</b></label>
                            <input type="text" class="form-control" id="customer" name="customer"
                                value="<?php echo e($item->customer); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="alamat" class="form-label"><b>Alamat</b></label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="3" readonly><?php echo e($item->alamat); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="sales" class="form-label"><b>Sales</b></label>
                            <input type="text" class="form-control" id="sales" name="sales"
                                value="<?php echo e($item->sales); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="telp" class="form-label"><b>No Telp</b></label>
                            <input type="number" class="form-control" id="telp" name="telp"
                                value="<?php echo e($item->telp); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="pengirim" class="form-label"><b>Pengirim</b></label>
                            <input type="text" class="form-control" id="pengirim" name="pengirim"
                                value="<?php echo e($item->pengirim); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="kelengkapankirim" class="form-label"><b>Kelengkapan Kirim</b></label>
                            <textarea class="form-control" id="kelengkapankirim" name="kelengkapankirim" rows="3" readonly><?php echo e($item->kelengkapankirim); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="gambar" class="form-label"><b>Gambar</b></label><br>
                            <img src="<?php echo e(url('/storage/gambar/' . $item->gambar)); ?>" width='60' height='60'
                                class="img img-responsive" id="gambar" name="gambar">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end view data -->

    <!-- delete data -->
    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="deleteModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($item->id); ?>">Delete Data Pinjam</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this Data?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <form action="<?php echo e(route('users.destroy', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end delete data -->

    <!-- Move data -->
    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="moveModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="moveModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="<?php echo e(route('users.update', $item->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="moveModalLabel<?php echo e($item->id); ?>">Ajukan Pengembalian</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="tanggal" class="form-label"><b>Tanggal</b></label>
                                <input type="date" class="form-control" id="tanggal" name="tanggal"
                                    value="<?php echo e($item->tanggal); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="gambar" class="form-label"><b>Gambar</b></label>
                                <input class="form-control" type="file" id="gambar" name="gambar"
                                    value="<?php echo e($item->gambar); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="serialnumber" class="form-label"><b>Serial Number</b></label>
                                <input type="text" class="form-control" id="serialnumber" name="serialnumber"
                                    value="<?php echo e($item->serialnumber); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="device" class="form-label"><b>Device</b></label>
                                <input type="text" class="form-control" id="device" name="device"
                                    value="<?php echo e($item->device); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="customer" class="form-label"><b>Customer</b></label>
                                <input type="text" class="form-control" id="customer" name="customer"
                                    value="<?php echo e($item->customer); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="alamat" class="form-label"><b>Alamat</b></label>
                                <textarea class="form-control" id="alamat" name="alamat" rows="3" readonly><?php echo e($item->alamat); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="sales" class="form-label"><b>Sales</b></label>
                                <input type="text" class="form-control" id="sales" name="sales"
                                    value="<?php echo e($item->sales); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="telp" class="form-label"><b>No Telp</b></label>
                                <input type="number" class="form-control" id="telp" name="telp"
                                    value="<?php echo e($item->telp); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="pengirim" class="form-label"><b>Pengirim</b></label>
                                <input type="text" class="form-control" id="pengirim" name="pengirim"
                                    value="<?php echo e($item->pengirim); ?>"readonly>
                            </div>
                            <div class="mb-3">
                                <label for="kelengkapankirim" class="form-label"><b>Kelengkapan Kirim</b></label>
                                <textarea class="form-control" id="kelengkapankirim" name="kelengkapankirim" rows="3" readonly><?php echo e($item->kelengkapankirim); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="tanggalkembali" class="form-label"><b>Tanggal Kembali</b></label>
                                <input type="date" class="form-control" id="tanggalkembali" name="tanggalkembali">
                            </div>
                            <div class="mb-3">
                                <label for="penerima" class="form-label"><b>Penerima</b></label>
                                <input type="text" class="form-control" id="penerima" name="penerima"
                                    placeholder="Masukan Nama Penerima">
                            </div>
                            <div class="mb-3">
                                <label for="kelengkapankembali" class="form-label"><b>Kelengkapan Kirim</b></label>
                                <textarea class="form-control" id="kelengkapankembali" name="kelengkapankembali" rows="3"
                                    placeholder="Contoh:Adaptor,Dus,Docking"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label"><b>Status</b></label>
                                <input type="text" class="form-control" id="status" name="status" value="1"
                                    readonly>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success">Pindah Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End Move data -->

    <!-- view kembali data -->
    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="viewkembaliModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="viewkembaliModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewModalLabel<?php echo e($item->id); ?>">View Data Pinjam</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="tanggal" class="form-label"><b>Tanggal</b></label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal"
                                value="<?php echo e($item->tanggal); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="serialnumber" class="form-label"><b>Serial Number</b></label>
                            <input type="text" class="form-control" id="serialnumber" name="serialnumber"
                                value="<?php echo e($item->serialnumber); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="device" class="form-label"><b>Device</b></label>
                            <input type="text" class="form-control" id="device" name="device"
                                value="<?php echo e($item->device); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="customer" class="form-label"><b>Customer</b></label>
                            <input type="text" class="form-control" id="customer" name="customer"
                                value="<?php echo e($item->customer); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="alamat" class="form-label"><b>Alamat</b></label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="3" readonly><?php echo e($item->alamat); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="sales" class="form-label"><b>Sales</b></label>
                            <input type="text" class="form-control" id="sales" name="sales"
                                value="<?php echo e($item->sales); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="telp" class="form-label"><b>No Telp</b></label>
                            <input type="number" class="form-control" id="telp" name="telp"
                                value="<?php echo e($item->telp); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="pengirim" class="form-label"><b>Pengirim</b></label>
                            <input type="text" class="form-control" id="pengirim" name="pengirim"
                                value="<?php echo e($item->pengirim); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="kelengkapankirim" class="form-label"><b>Kelengkapan Kirim</b></label>
                            <textarea class="form-control" id="kelengkapankirim" name="kelengkapankirim" rows="3" readonly><?php echo e($item->kelengkapankirim); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="tanggalkembali" class="form-label"><b>Tanggal Kembali</b></label>
                            <input type="date" class="form-control" id="tanggalkembali" name="tanggalkembali"
                                value="<?php echo e($item->tanggalkembali); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="penerima" class="form-label"><b>Penerima</b></label>
                            <input type="text" class="form-control" id="penerima" name="penerima"
                                value="<?php echo e($item->penerima); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="kelengkapankembali" class="form-label"><b>Kelengkapan Kembali</b></label>
                            <textarea class="form-control" id="kelengkapankembali" name="kelengkapankembali" rows="3" readonly><?php echo e($item->kelengkapankembali); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="gambar" class="form-label"><b>Gambar</b></label><br>
                            <img src="<?php echo e(url('/storage/gambar/' . $item->gambar)); ?>" width='60' height='60'
                                class="img img-responsive" id="gambar" name="gambar">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end view kembali data -->

    <!-- add kembali edit Data -->
    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editkembaliModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="editkembaliModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="POST" action="<?php echo e(route('users.update', $item->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel<?php echo e($item->id); ?>">Edit Data Pinjam</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="tanggal" class="form-label"><b>Tanggal</b></label>
                                <input type="date" class="form-control" id="tanggal" name="tanggal"
                                    value="<?php echo e($item->tanggal); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="serialnumber" class="form-label"><b>Serial Number</b></label>
                                <input type="text" class="form-control" id="serialnumber" name="serialnumber"
                                    value="<?php echo e($item->serialnumber); ?>">
                            </div>
                            <div class="form-group mb-3">
                                <label for="device"><b>Tipe Device</b></label>
                                <select class="form-control selectpicker" name="device" id="device"
                                    data-live-search="true" required>
                                    <option value="Pilih Model">Pilih Model</option>
                                    <option value="D1" data-tokens="D1"
                                        <?php echo e($item->device == 'D1' ? 'selected' : ''); ?>>D1</option>
                                    <option value="D1 Moka" data-tokens="D1 Moka"
                                        <?php echo e($item->device == 'D1 Moka' ? 'selected' : ''); ?>>D1 Moka</option>
                                    <option value="D1-Pro" data-tokens="D1-Pro"
                                        <?php echo e($item->device == 'D1-Pro' ? 'selected' : ''); ?>>D1-Pro</option>
                                    <option value="D1w" data-tokens="D1w"
                                        <?php echo e($item->device == 'D1w' ? 'selected' : ''); ?>>D1w</option>
                                    <option value="D2-401" data-tokens="D2-401"
                                        <?php echo e($item->device == 'D2-401' ? 'selected' : ''); ?>>D2-401</option>
                                    <option value="D2-402" data-tokens="D2-402"
                                        <?php echo e($item->device == 'D2-402' ? 'selected' : ''); ?>>D2-402</option>
                                    <option value="D2-Pro" data-tokens="D2-Pro"
                                        <?php echo e($item->device == 'D2-Pro' ? 'selected' : ''); ?>>D2-Pro</option>
                                    <option value="D3 504 lama" data-tokens="D3 504 lama"
                                        <?php echo e($item->device == 'D3 504 lama' ? 'selected' : ''); ?>>D3 504 lama</option>
                                    <option value="D3 505 lama" data-tokens="D3 505 lama"
                                        <?php echo e($item->device == 'D3 505 lama' ? 'selected' : ''); ?>>D3 505 lama</option>
                                    <option value="D3 506 lama" data-tokens="D3 506 lama"
                                        <?php echo e($item->device == 'D3 506 lama' ? 'selected' : ''); ?>>D3 506 lama</option>
                                    <option value="D3-504" data-tokens="D3-504"
                                        <?php echo e($item->device == 'D3-504' ? 'selected' : ''); ?>>D3-504</option>
                                    <option value="D3-505" data-tokens="D3-505"
                                        <?php echo e($item->device == 'D3-505' ? 'selected' : ''); ?>>D3-505</option>
                                    <option value="D3-506" data-tokens="D3-506"
                                        <?php echo e($item->device == 'D3-506' ? 'selected' : ''); ?>>D3-506</option>
                                    <option value="D3-501 Moka" data-tokens="D3-501 Moka"
                                        <?php echo e($item->device == 'D3-501 Moka' ? 'selected' : ''); ?>>D3-501 Moka</option>
                                    <option value="D3-503 Moka" data-tokens="D3-503 Moka"
                                        <?php echo e($item->device == 'D3-503 Moka' ? 'selected' : ''); ?>>D3-503 Moka</option>
                                    <option value="D3 DS1" data-tokens="D3 DS1"
                                        <?php echo e($item->device == 'D3 DS1' ? 'selected' : ''); ?>>D3 DS1</option>
                                    <option value="D3 DS1 Extention Display" data-tokens="D3 DS1 Extention Display"
                                        <?php echo e($item->device == 'D3 DS1 Extention Display' ? 'selected' : ''); ?>>D3 DS1
                                        Extention Display</option>
                                    <option value="D3 DS1 Extention Display TS" data-tokens="D3 DS1 Extention Display TS"
                                        <?php echo e($item->device == 'D3 DS1 Extention Display TS' ? 'selected' : ''); ?>>D3 DS1
                                        Extention Display TS</option>
                                    <option value="D4-502" data-tokens="D4-502"
                                        <?php echo e($item->device == 'D4-502' ? 'selected' : ''); ?>>D4-502</option>
                                    <option value="D4-503" data-tokens="D4-503"
                                        <?php echo e($item->device == 'D4-503' ? 'selected' : ''); ?>>D4-503</option>
                                    <option value="D4-503 White" data-tokens="D4-503 White"
                                        <?php echo e($item->device == 'D4-503 White' ? 'selected' : ''); ?>>D4-503 White</option>
                                    <option value="D4-504" data-tokens="D4-504"
                                        <?php echo e($item->device == 'D4-504' ? 'selected' : ''); ?>>D4-504</option>
                                    <option value="D4-504 White" data-tokens="D4-504 White"
                                        <?php echo e($item->device == 'D4-504 White' ? 'selected' : ''); ?>>D4-504 White</option>
                                    <option value="D4-505" data-tokens="D4-505"
                                        <?php echo e($item->device == 'D4-505' ? 'selected' : ''); ?>>D4-505</option>
                                    <option value="D4-505 DT" data-tokens="D4-505 DT"
                                        <?php echo e($item->device == 'D4-505 DT' ? 'selected' : ''); ?>>D4-505 DT</option>
                                    <option value="D4 Falcon 1" data-tokens="D4 Falcon 1"
                                        <?php echo e($item->device == 'D4 Falcon 1' ? 'selected' : ''); ?>>D4 Falcon 1</option>
                                    <option value="M2-202" data-tokens="M2-202"
                                        <?php echo e($item->device == 'M2-202' ? 'selected' : ''); ?>>M2-202</option>
                                    <option value="M2-202 iSeller" data-tokens="M2-202 iSeller"
                                        <?php echo e($item->device == 'M2-202 iSeller' ? 'selected' : ''); ?>>M2-202 iSeller</option>
                                    <option value="M2-203" data-tokens="M2-203"
                                        <?php echo e($item->device == 'M2-203' ? 'selected' : ''); ?>>M2-203</option>
                                    <option value="M2-203 iSeller" data-tokens="M2-203 iSeller"
                                        <?php echo e($item->device == 'M2-203 iSeller' ? 'selected' : ''); ?>>M2-203 iSeller</option>
                                    <option value="M2-203 White" data-tokens="M2-203 White"
                                        <?php echo e($item->device == 'M2-203 White' ? 'selected' : ''); ?>>M2-203 White</option>
                                    <option value="M2 Pro" data-tokens="M2 Pro"
                                        <?php echo e($item->device == 'M2 Pro' ? 'selected' : ''); ?>>M2 Pro</option>
                                    <option value="M2 Max" data-tokens="M2 Max"
                                        <?php echo e($item->device == 'M2 Max' ? 'selected' : ''); ?>>M2 Max</option>
                                    <option value="M2 Swift 1S" data-tokens="M2 Swift 1S"
                                        <?php echo e($item->device == 'M2 Swift 1S' ? 'selected' : ''); ?>>M2 Swift 1S</option>
                                    <option value="M2 Swift 1P" data-tokens="M2 Swift 1P"
                                        <?php echo e($item->device == 'M2 Swift 1P' ? 'selected' : ''); ?>>M2 Swift 1P</option>
                                    <option value="M2 Swift PDA" data-tokens="M2 Swift PDA"
                                        <?php echo e($item->device == 'M2 Swift PDA' ? 'selected' : ''); ?>>M2 Swift PDA</option>
                                    <option value="M2 Swift 1 Scanner" data-tokens="M2 Swift 1 Scanner"
                                        <?php echo e($item->device == 'M2 Swift 1 Scanner' ? 'selected' : ''); ?>>M2 Swift 1 Scanner
                                    </option>
                                    <option value="M2 Swift 1 Printer" data-tokens="M2 Swift 1 Printer"
                                        <?php echo e($item->device == 'M2 Swift 1 Printer' ? 'selected' : ''); ?>>M2 Swift 1 Printer
                                    </option>
                                    <option value="R1 201" data-tokens="R1 201"
                                        <?php echo e($item->device == 'R1 201' ? 'selected' : ''); ?>>R1 201</option>
                                    <option value="R1 202" data-tokens="R1 202"
                                        <?php echo e($item->device == 'R1 202' ? 'selected' : ''); ?>>R1 202</option>
                                    <option value="S1 701" data-tokens="S1 701"
                                        <?php echo e($item->device == 'S1 701' ? 'selected' : ''); ?>>S1 701</option>
                                    <option value="K1 101" data-tokens="K1 101"
                                        <?php echo e($item->device == 'K1 101' ? 'selected' : ''); ?>>K1 101</option>
                                    <option value="K2 201" data-tokens="K1 201"
                                        <?php echo e($item->device == 'K2 201' ? 'selected' : ''); ?>>K2 201</option>
                                    <option value="X1 Scanner" data-tokens="X1 Scanner"
                                        <?php echo e($item->device == 'X1 Scanner' ? 'selected' : ''); ?>>X1 Scanner</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="customer" class="form-label"><b>Customer</b></label>
                                <input type="text" class="form-control" id="customer" name="customer"
                                    value="<?php echo e($item->customer); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="alamat" class="form-label"><b>Alamat</b></label>
                                <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo e($item->alamat); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="sales" class="form-label"><b>Sales</b></label>
                                <input type="text" class="form-control" id="sales" name="sales"
                                    value="<?php echo e($item->sales); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="telp" class="form-label"><b>No Telp</b></label>
                                <input type="number" class="form-control" id="telp" name="telp"
                                    value="<?php echo e($item->telp); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="pengirim" class="form-label"><b>Pengirim</b></label>
                                <input type="text" class="form-control" id="pengirim" name="pengirim"
                                    value="<?php echo e($item->pengirim); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="kelengkapankirim" class="form-label"><b>Kelengkapan Kirim</b></label>
                                <textarea class="form-control" id="kelengkapankirim" name="kelengkapankirim" rows="3"
                                    placeholder="Contoh:Adaptor,Dus,Docking"><?php echo e($item->kelengkapankirim); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="tanggalkembali" class="form-label"><b>Tanggal Kembali</b></label>
                                <input type="date" class="form-control" id="tanggalkembali" name="tanggalkembali"
                                    value="<?php echo e($item->tanggalkembali); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="penerima" class="form-label"><b>Penerima</b></label>
                                <input type="text" class="form-control" id="penerima" name="penerima"
                                    value="<?php echo e($item->penerima); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="kelengkapankembali" class="form-label"><b>Kelengkapan Kembali</b></label>
                                <textarea class="form-control" id="kelengkapankembali" name="kelengkapankembali" rows="3"
                                    placeholder="Contoh:Adaptor,Dus,Docking"><?php echo e($item->kelengkapankembali); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label"><b>Status</b></label>
                                <input type="text" class="form-control" id="status" name="status"
                                    value="<?php echo e($item->status); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="gambar" class="form-label"><b>Gambar</b></label><br>
                                <input class="form-control" type="file" id="gambar" name="gambar">
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-warning">Edit Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end kembali edit data -->

    <div class="container-fluid scroll mt-3 ">
        <table class="table table-striped table-hover table-bordered">
            <thead class="table-dark headfix">
                <th>No</th>
                <th>Tanggal</th>
                
                <th>Serial Number</th>
                <th>Tipe Device</th>
                <th>Customer</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d/m/Y')); ?></td>
                        
                        <td><?php echo e($item->serialnumber); ?></td>
                        <td><?php echo e($item->device); ?></td>
                        <td><?php echo e($item->customer); ?></td>
                        <td>
                            <?php if(request()->is('pinjam')): ?>
                                <a href="#" class="btn btn-warning" data-toggle="modal"
                                    data-target="#editModal<?php echo e($item->id); ?>"><i
                                        class="fa-solid fa-pen-to-square"></i></a>
                            <?php endif; ?>

                            <?php if(request()->is('pinjam')): ?>
                                <a href="#" class="btn btn-primary" data-toggle="modal"
                                    data-target="#viewModal<?php echo e($item->id); ?>"><i class="fa-solid fa-eye"></i></a>
                            <?php endif; ?>

                            <?php if(request()->is('kembali')): ?>
                                <a href="#" class="btn btn-warning" data-toggle="modal"
                                    data-target="#editkembaliModal<?php echo e($item->id); ?>"><i
                                        class="fa-solid fa-pen-to-square"></i></a>
                            <?php endif; ?>

                            <?php if(request()->is('kembali')): ?>
                                <a href="#" class="btn btn-primary" data-toggle="modal"
                                    data-target="#viewkembaliModal<?php echo e($item->id); ?>"><i
                                        class="fa-solid fa-eye"></i></a>
                            <?php endif; ?>

                            <a href="#" class="btn btn-danger" data-toggle="modal"
                                data-target="#deleteModal<?php echo e($item->id); ?>"><i class="fa-solid fa-trash"></i></a>

                            <?php if(request()->is('pinjam')): ?>
                                <a href="#" class="btn btn-success" data-toggle="modal"
                                    data-target="#moveModal<?php echo e($item->id); ?>"><i
                                        class="fa-solid fa-paper-plane"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iminpinjam\resources\views/pinjam/index.blade.php ENDPATH**/ ?>